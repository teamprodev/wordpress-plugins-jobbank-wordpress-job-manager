<?php
	
	include('dir_setting.php');
?>