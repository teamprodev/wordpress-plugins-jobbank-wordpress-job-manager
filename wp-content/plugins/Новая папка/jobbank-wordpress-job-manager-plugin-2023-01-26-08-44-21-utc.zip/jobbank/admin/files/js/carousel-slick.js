jQuery( document ).ready(function() { 
	jQuery('.caretories-slick').slick({
  
  infinite: false,
  speed: 300,
  slidesToShow: 10,      
   arrows: true,  
  
  
  variableWidth: true
});
});
